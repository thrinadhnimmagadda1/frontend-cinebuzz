import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from '../api/axios';
import '../App.css';


const WelcomePage = () => {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const response = await axios.get('/api/GetMoviesWithReviews');
        setMovies(response.data);
      } catch (error) {
        console.error('Error fetching movies:', error);
      }
    };
    fetchMovies();
  }, []);

  return (
    <div className="welcome-page">
      <h1>Welcome to CineBuzz</h1>
      <div className="movie-list">
        {movies.map((movie) => (
          <div key={movie.id} className="movie-card">
            <h3>{movie.title}</h3>
            <p>Genre: {movie.genre}</p>
            <p>Rating: {movie.rating} stars</p>
            <Link to={`/movie/${movie.id}`} className="movie-link">
              View Details
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WelcomePage;
